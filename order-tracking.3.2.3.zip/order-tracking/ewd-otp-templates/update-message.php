<div class='ewd-otp-update'>
	<?php echo esc_html( $this->update_message ); ?>
</div>