<div class='ewd-otp-results-field'>
	<?php echo esc_html( $this->get_label( 'label-sales-rep-display-email' ) ); ?>: <?php echo esc_html( $this->sales_rep->email ); ?>
</div>