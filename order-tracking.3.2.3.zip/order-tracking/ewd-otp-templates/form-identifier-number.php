<div class='ewd-otp-form-identifier'>

	<label for='ewd_otp_identifier_number' class='ewd-otp-field-label'><?php echo esc_html( $this->order_field_text ); ?>: </label>
	
	<input type='text' name='ewd_otp_identifier_number' placeholder='<?php echo esc_attr( $this->get_identifier_placeholder_label() ); ?>' />

</div>