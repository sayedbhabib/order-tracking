<div class='ewd-otp-results-field'>
	<?php echo esc_html( $this->get_label( 'label-customer-display-name' ) ); ?>: <?php echo esc_html( $this->customer->name ); ?>
</div>