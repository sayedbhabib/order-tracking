<div class='ewd-otp-form-submit'>

	<label for='ewd_otp_form_submit'></label>

	<input type='submit' class='ewd-otp-submit' name='ewd_otp_form_submit' value='<?php echo esc_attr( $this->submit_text ); ?>' />

</div>