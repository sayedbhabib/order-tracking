<div class='ewd-otp-form-email'>
	
	<label for='ewd_otp_form_email' class='ewd-otp-field-label'><?php echo esc_html( $this->email_field_text ); ?>: </label>
	
	<input type='email' class='ewd-otp-text-input' name='ewd_otp_form_email' placeholder='<?php echo esc_attr( $this->get_email_placeholder_label() ); ?>' />
	
</div>