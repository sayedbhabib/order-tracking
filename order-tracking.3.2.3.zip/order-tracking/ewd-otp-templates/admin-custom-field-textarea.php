<textarea name='ewd-otp-custom-field-<?php echo esc_attr( $this->custom_field->id ); ?>'>
	<?php echo esc_textarea( $this->custom_field->field_value ); ?>
</textarea>