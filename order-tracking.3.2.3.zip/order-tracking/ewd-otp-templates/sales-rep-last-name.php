<div class='ewd-otp-results-field'>
	<?php echo esc_html( $this->get_label( 'label-sales-rep-display-last-name' ) ); ?>: <?php echo esc_html( $this->sales_rep->last_name ); ?>
</div>