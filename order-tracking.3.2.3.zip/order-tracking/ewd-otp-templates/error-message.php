<div class='ewd-otp-error'>
  <?php echo esc_html( $this->error_message ); ?>
</div>