=== Order Tracking - WordPress Status Tracking Plugin ===
Contributors: Rustaurius, EtoileWebDesign
Donate Link: http://www.etoilewebdesign.com/plugin-donations/
Tags: order tracking, status tracking, order status, woocommerce order tracking, order shortcode, order management, delivery, deliveries, shipping, track, tracking, order processing, inventory management, customer orders, support tickets, helpdesk, help desk, help desk software, support software
Requires at least: 5.0
Tested up to: 6.1
Stable tag: 3.2.3
License: GPLv3
License URI:http://www.gnu.org/licenses/gpl-3.0.html

Order tracking, status and project management plugin. Create tickets and tracking numbers. Send email updates. Works standalone and with WooCommerce.

== Description ==

Add a full order tracking and management system to your site. Quickly and easily create and update orders, and then let customers view them on your site via a modern, responsive tracking form. 

<a href='http://www.etoilewebdesign.com/order-tracking-demo/'>Status Tracking Demo</a>

Since the plugin can be used for the status tracking of anything, not just orders, it's also a great tool for project management.

<a href='http://etoilewebdesign.com/project-status-demo/'>Project Status Demo</a>

<strong>The plugin includes Gutenberg blocks as well as shortcodes, so you can display your tracking form on any page, no matter which page editing system you are using.</strong>

= Order Tracking Key Features =

* Create an unlimited number of orders
* Set up searchable orders or ticket numbers / tracking numbers for customers. Order management made simple!
* Easily update and change the order status in the plugin admin panel.
* Create custom statuses tailored to your business.
* Require email verficiation to view order tracking.
* Order status notifications that automatically send an alert email to a customer whenever an order is created or updated.
* Choose what order tracking information gets displayed in the results when you place the order shortcode or block on a page.

<em>Order Tracking is very user friendly and comes with a walk-through that runs automatically when you activate the plugin and will help you set up your statuses and create your tracking page!</em>

[youtube https://www.youtube.com/watch?v=ylJ6CET7ppU]

It's the simplest system for tracking your orders and statuses. Perfect for your shipping company or project management.

`[tracking-form]
`

Simply insert the <em>Tracking Form</em> block or the shortcode above to add an order tracking form to your site.

It's easy to modify the styling of your tracking form, which will help it to further fit with the look of your site. We provide a list of the most common classes from our plugin, as well as an exmaple of how to implement custom CSS, [in our documentation](https://doc.etoilewebdesign.com/plugins/order-tracking/user/styling/css).

Status tracking options are available to decide what information is displayed, to print orders, to hide blank fields, to send out order status update emails, order alerts and more! Order management has never been this simple.

= Additional Order Tracking and Order Status Features =

* Hide or delete orders.
* Hide fields from the tracking page that have no value. 
* Custom order alert emails that can be associated with different statuses (e.g. for order processing, shipments, project deadlines, etc.).
* Customize the subject and text of all notification emails.
* Print orders from the tracking page.
* Add public and private notes to orders.
* Responsive and customizable CSS.
* Option for AJAX order tracking results or to display them in a new window.
* Date format and timezone settings.

= WooCommerce Order Tracking (Requires Premium) =

Turn on the included WooCommerce tracking integration (premium) to automatically create new orders in our plugin whenever someone checks out via your WooCommerce shop! With this you can provide WooCommerce order updates straight from within this plugin, allowing you to take advantage of the additional WooCommerce tracking features, like custom fields, to provide specific info for your customers.

* WooCommerce order tracking integration in which, for every new order created via WooCommerce checkout, a new order is automatically created in the Status Tracking plugin.
* WooCommerce tracking made easy with automatically-assigned order number (with options to add and customize a prefix and/or suffix).
* WooCommerce order update alert and email automatically sent to the customer with this order number.
* WooCommerce tracking updates: When an order is updated in WooCommerce, it is also automatically updated in Status Tracking, and vice versa.
* WooCommerce status notifications: An email will automatically be sent to the customer on order update / status change.
* Set equivalent status in this plugin for existing WooCommerce statuses to make direct syncing even more powerful.

= Customers and Sales Reps (Requires Premium) =

For even more refined order management, you can create customers and sales reps in the plugin, and then assign orders directly to them. This will make the browsing experience easier for your customers and the order management easier for you.

* Add a customer tracking form to your site, which displays all of a specific customer's orders in one table, with links to each individual order's tracking page.
* Associate a customer with a WordPress user account, so they can log in to your site (front end, not back end) and see all of their orders without having to enter any tracking information.
* Associate a sales rep with a WordPress user acconunt, to give them access to a special admin portal where they can manage only those orders assigned to them.
* You can also add a sales rep tracking form to your site, which displays all of a specific sales rep's orders in one table, with links to each individual order's tracking page. This is great if you would prefer that sales reps manage orders form the front end instead of the admin.
* Both customers and sales reps can download / export their orders straight from the front end.

= Premium Order Tracking Features =

The premium version also comes with many other additional features to enhance your order status tracking experience and offer the best in order management. These include new layout options, locations, custom fields, and the ability to let customers submit their own orders and to require payment for orders. 

* Create different locations to associate with orders and with specific statuses and updates.
* Dozens of styling and labelling options to enhance the order tracking experience.
* PayPal integration to allow/require payment for orders.
* Customer order form to let customers create their own orders, which can then be managed and updated just like any other order.
* Custom fields that can be assigned to orders, customers or sales reps. Can be used to display extra information on the tracking page (such as weight, estimated delivery, price, etc.) or to gather extra info in the customer order form.
* Add Google reCAPTCHA protection to the customer order form. 
* Import orders from a spreadsheet. Great for adding many orders at once or bulk updating existing orders.
* Export orders to a spreadsheet, to allow for bulk updating or transfer to a different system (e.g. CRM).

[youtube https://www.youtube.com/watch?v=q1ohsIfHgyg]

= Project Management =

The tracking plugin isn't just for order management and order alerts. By making use of the available premium features, you can transform the plugin into a project management tool.

For example, by treating orders as projects, you could:

* Use the Sales Reps feature to set up project managers and assign specific projects to them.
* Create customers and assign specific projects and project managers to those customers.
* Use the available labelling options to customize the wording of your forms and tracking pages (e.g. swap <em>project</em> for <em>order</em>, <em>project manager</em> for <em>sales rep</em>, etc.) to cater to the project management experience.

With the Order Tracking plugin, you can keep your customers up to date with their order delivery status. Whether it's for WooCommerce tracking or use as a standalone status tracking solution, the included feature set will take care of all your order tracking needs. You can send a shipping email when the order is placed or is ready, and let your customers track shipping in the easiest way possible. 

For further information and purchasing options, please visit our <strong><a href="https://www.etoilewebdesign.com/plugins/order-tracking/">order tracking WordPress plugin</a></strong> homepage.

** We are also pleased to offer a free 7-day trial of the premium version, which you can use to test out features like customers and sales reps, as well as the WooCommerce integration and styling options, before buying! **

= Customize Your Order Tracking with the Included Template System =

The Order Tracking plugin is built on a series of templates, such that everything that displays on the front end of the plugin can be customized by creating your own template files (to modify and/or overwrite the existing templates files). This gives you a powerful and non-destructive way to custmoize the look and functionality of your tracking forms and results pages to your exact needs. More info about this can be found <a href="https://doc.etoilewebdesign.com/plugins/order-tracking/developer/">in our documentation</a>. 

= Order Tracking Blocks =

* <strong>Tracking Form</strong>: Display the main order tracking form.
* <strong>Customer Form</strong> (premium): Display the customer tracking form.
* <strong>Sales Rep Form</strong> (premium): Display the sales rep tracking form.
* <strong>Customer Order Form</strong> (premium): Display the customer order form.

= Order Tracking Shortcodes =

* <strong>[tracking-form]</strong>: Display the main order tracking form.
* <strong>[customer-form]</strong> (premium): Display the customer tracking form.
* <strong>[sales-rep-form]</strong> (premium): Display the sales rep tracking form.
* <strong>[customer-order]</strong> (premium): Display the customer order form.

For a complete list of blocks and shortcodes, and their associated parameters/attributes, please see [here](https://doc.etoilewebdesign.com/plugins/order-tracking/user/blocks-shortcodes/).

<strong>The Status Tracking plugin also includes Zendesk Integration!</strong>View the <a href='https://www.etoilewebdesign.com/status-tracking-zendesk-integration/'>the tutorial on our website</a> for more information on how to set it up.

= Status Tracking Additional Languages =
Thanks to the generous contribution of many of those who use our order tracking plugin, we're able to include translation files for the following languages:

* Arabic (thanks to <a href='http://www.webgearmedia.com/'>Webgear Media</a>)
* Italian (thanks to MD Ariful)
* German (thanks to Benko)
* Lithuanian
* Norwegian (thanks to EinarSkaug)
* Persian (thanks to <a href="http://dilmanj.ir/">Poorya Zeynalzadeh</a>)
* Polish (thanks to Jakub G.)
* Portugese (thanks to Jaoa)
* Spanish (thanks to Pablo M.)
* Turkish
* Vietnamese

= For help and support, please see: =

* Our documentation, here: [https://doc.etoilewebdesign.com/plugins/order-tracking/user/](https://doc.etoilewebdesign.com/plugins/order-tracking/user/)
* Our FAQ pages, here: [https://doc.etoilewebdesign.com/plugins/order-tracking/user/faq](https://doc.etoilewebdesign.com/plugins/order-tracking/user/faq), and here: [https://wordpress.org/plugins/order-tracking/faq/](https://wordpress.org/plugins/order-tracking/faq/)
* Our installation guide and information about the walk-through, here: [https://doc.etoilewebdesign.com/plugins/order-tracking/user/getting-started/install](https://doc.etoilewebdesign.com/plugins/order-tracking/user/getting-started/install)
* Our tutorial videos, here: [https://www.youtube.com/playlist?list=PLEndQUuhlvSqa6Txwj1-Ohw8Bj90CIRl0](https://www.youtube.com/playlist?list=PLEndQUuhlvSqa6Txwj1-Ohw8Bj90CIRl0)
* The Order Tracking support forum, here: [https://wordpress.org/support/plugin/order-tracking/](https://wordpress.org/support/plugin/order-tracking/)
* Our Support Center, here: [https://www.etoilewebdesign.com/support-center/](https://www.etoilewebdesign.com/support-center/)

-----------------------------------------------------------------------------------

== Installation ==

1. Upload the 'order-tracking' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

or

1. Go to the 'Plugins' menu in WordPress and click 'Add New'
2. Search for 'Status Tracking' and select 'Install Now'
3. Activate the plugin when prompted

= Getting Started =

After activating the plugin, <strong>a walk-through will run automatically</strong>, which will help you to set up your statuses, add your tracking form and set a few key options. 

For more info on installing and activating the plugin, and on the walk-through, please see here: [https://doc.etoilewebdesign.com/plugins/order-tracking/user/getting-started/install](https://doc.etoilewebdesign.com/plugins/order-tracking/user/getting-started/install)

= For help and support, please see: =

* Our documentation, here: [https://doc.etoilewebdesign.com/plugins/order-tracking/user/](https://doc.etoilewebdesign.com/plugins/order-tracking/user/)
* Our FAQ pages, here: [https://doc.etoilewebdesign.com/plugins/order-tracking/user/faq](https://doc.etoilewebdesign.com/plugins/order-tracking/user/faq), and here: [https://wordpress.org/plugins/order-tracking/faq/](https://wordpress.org/plugins/order-tracking/faq/)
* Our tutorial videos, here: [https://www.youtube.com/playlist?list=PLEndQUuhlvSqa6Txwj1-Ohw8Bj90CIRl0](https://www.youtube.com/playlist?list=PLEndQUuhlvSqa6Txwj1-Ohw8Bj90CIRl0)
* The Order Tracking support forum, here: [https://wordpress.org/support/plugin/order-tracking/](https://wordpress.org/support/plugin/order-tracking/)
* Our Support Center, here: [https://www.etoilewebdesign.com/support-center/](https://www.etoilewebdesign.com/support-center/)

--------------------------------------------------------------

== Frequently Asked Questions ==


= Is there a shortcode to display the order tracking form? =

Yes, you can use the `[tracking-form]` shortcode. For more info, see [here](https://doc.etoilewebdesign.com/plugins/order-tracking/user/blocks-shortcodes/tracking-form-shortcode).

= Is there a Gutenberg block to display the order tracking form? =

Yes, you can search for the **Tracking Form** block. Alternatively, you'll find it in its own block category/section called **Order Tracking**. For more info, see [here](https://doc.etoilewebdesign.com/plugins/order-tracking/user/blocks-shortcodes/tracking-form-block).

= What are all the available blocks and shortcodes? =

For a complete list of blocks and shortcodes, and their associated parameters/attributes, please see [here](https://doc.etoilewebdesign.com/plugins/order-tracking/user/blocks-shortcodes/).

= Is it possible to delete data of an incorrect order completely? =
If you click the checkbox beside the incorrect order and select "Delete", that should get rid of the order.

= How do I change the title of “Order Form Instructions”? =

You can edit “Order Form Instructions” on the "Settings" page. They can also be set as an attribute. Instructions set as an attribute will take priority.

= How do I change the label “Order Number” field to, for example, “Job Number” in the front end display? =

To change the label, try adding these attributes into your shortcode:
[tracking-form order_field_text='Job Number' field_names='Order Number=>Job Number']

= Is there a way to modify multiple field labels? =

In the premium version, you can change the field labels by using the "Labelling" area of the "Settings" tab.

= My order graph is not displaying properly, all of the statuses are overlapping. How do I fix this? =

Make sure that you set the column “Percentages” on the order statuses page. If the problem persists you can also try editing the spacing by adding some custom CSS.

= Is this compatible with WPML? =

Yes. All the strings/labels are localized in the code. As such, they will be picked up by WPML's String Translation tool for easy direct translating. 

For more info on translating the plugin, please see [here](https://doc.etoilewebdesign.com/plugins/order-tracking/user/labelling/translating).

= How do I add a map to the tracking page? =

You first need to make sure the **Tracking Map** choice is selected for the **Order Information Displayed** option in the Basic area of the Settings page. Then you need to provide your Google Maps API key in the designated area.

Then you need to make sure you have provided latitude and longitude coordinates for your locations.

After this, when you set an order to a specific location in the premium version, that location will show on a map on the tracking results page.

= Can Sales Reps manage and create their own orders? =

Yes. In the premium version, you just need to associate the sales rep with an existing WordPress user account and then they will have access to their own customized dashboard in the WordPress admin. For more info, please see [here](https://doc.etoilewebdesign.com/plugins/order-tracking/user/sales-reps/wordpress-user).

= Is it possible for my customer to view their orders without entering the ID? =

Yes. In the premium version, you just need to associate the customer with an existing WordPress user account. Then, when they log in and go to the page with the customer tracking form on it, they will automatically see all of their orders. For more info, please see [here](https://doc.etoilewebdesign.com/plugins/order-tracking/user/customers/wordpress-user).

= Can I add extra fields to my orders =

Yes, the premium version of the plugin includes the **Custom Fields** feature, which lets you add extra fields to your orders and to the customer order form. For more info, see [here](https://doc.etoilewebdesign.com/plugins/order-tracking/user/custom-fields).

= What are the columns for the spreadsheet and is it possible to add more information? =

Additional information about an order can be added using custom fields, or by using the "Public Notes" at the moment. The columns that can be uploaded currently are:

Number, Name, Order Status, Location, Display, Public Notes, Private Notes, Email, Show in Admin Table, Sales Rep ID

as well as those with the same name as a custom field (ex: "Specs").

= What is enabled in the premium version? =

For more info about the premium version, please see here: https://doc.etoilewebdesign.com/plugins/order-tracking/user/premium/benefits

= For help and support, please see: =

* Our documentation, here: [https://doc.etoilewebdesign.com/plugins/order-tracking/user/](https://doc.etoilewebdesign.com/plugins/order-tracking/user/)
* Our installation guide and information about the walk-through, here: [https://doc.etoilewebdesign.com/plugins/order-tracking/user/getting-started/install](https://doc.etoilewebdesign.com/plugins/order-tracking/user/getting-started/install)
* Our tutorial videos, here: [https://www.youtube.com/playlist?list=PLEndQUuhlvSqa6Txwj1-Ohw8Bj90CIRl0](https://www.youtube.com/playlist?list=PLEndQUuhlvSqa6Txwj1-Ohw8Bj90CIRl0)
* The Order Tracking support forum, here: [https://wordpress.org/support/plugin/order-tracking/](https://wordpress.org/support/plugin/order-tracking/)
* Our Support Center, here: [https://www.etoilewebdesign.com/support-center/](https://www.etoilewebdesign.com/support-center/)


== Screenshots ==

1. Sample order information with graphic, order info, map, notes and past statuses
2. Order tracking form
3. Tracking form with email option enabled
4. Customer tracking form
5. Customer tracking results
6. Sales rep tracking form
7. Sales rep tracking results
8. Customer order form to allow customers to submit their own orders
9. Tracking page with the default graphic
10. Tracking page with the 'Round' graphic
11. Tracking page with the 'Streamlined' graphic
12. Set up as a project status tracking tool
13. Project status project manager view
14. Project status customer view
15. Adding the order tracking Gutenberg block to a page
16. The Status Tracking plugin dashboard
17. The orders overview screen
18. The order create/edit screen
19. WooCommerce order tracking integration features
20. Customizing the order tracking notification emails
21. Adding/editing order statuses
22. Adding/editing order locations
23. Adding custom fields
24. The customers overview screen
25. Editing a customer
26. The sales rep overview screen
27. Editing a sales rep
28. Enabling payments for orders
29. The styling options to control fonts, colours, spacing, etc.


== Changelog ==

= 3.2.3 (2023-01-04) =
- Fixes a potential fatal error on the settings page.

= 3.2.2 (2023-01-03) =
- Update to the settings page to correct an issue that could cause an error to display for checkbox options.
- Fixed issue with customers tab (in the admin) not paginating correctly.

= 3.2.1 (2022-12-19) =
- Corrected an issue sometimes causing a notice or error when creating a customer or sales rep after updating the plugin.
- Updating an incorrect link and a typo in the admin screens.

= 3.2.0 (2022-12-09) =
- Added new tutorial videos to the settings pages that explain and show what each option does.
- Added quick links to the admin about page to re-run the walk-through, view tutorial videos and suggest a feature.
- Added the ability to specify a customer number for each customer and a sales rep number for each sales rep, which can be used in the corresponding tracking forms instead of the auto-generated ID.
- Added filtering options (status, time period, customer and/or sales rep) to the export functionality. 
- Fixed an issue with certain characters not being supported in exports.
- Tested with PHP 8.1 and updated deprecated function use.

= 3.1.7 (2022-10-05) =
- Fixed an issue in which, if you manually added a new order in the admin and then immediately clicked Update Order, it would create a duplicate new order.

= 3.1.6 (2022-08-17) =
- Updated the import process so it automatically assigns an order to a customer if the email address for the order provided in the spreadsheet matches the email address of an existing customer (must have the "Assign Orders to Customers" option enabled). 
- Added a div around the instructions text in the various tracking forms, so that text can be specifically targeted for custom styling. 
- Fixed an issue in which orders couldn't have their payment status set back to no via the admin.
- Small styling updates for the order edit screen.

= 3.1.5 (2022-06-16) =
- Updated the customer and sales rep form result tables to make use of the "Use WP Timezone" and "Date/Time Format" settings.
- On the admin edit screen for a sales rep or customer, updated the table that shows all associated orders to make use of the "Use WP Timezone" and "Date/Time Format" settings.

= 3.1.4 (2022-06-08) =
- Added a context to sanitize title calls, to allow for customization of them. 

= 3.1.3 (2022-05-20) =
- Tested with WordPress 6.0.

= 3.1.2 (2022-05-17) =
- Added previews for Gutenberg blocks (i.e. on the page edit screen, when you add the block, it will show a preview).

= 3.1.1 (2022-04-14) =
- Added a redirect option for the customer order form. Use the success_redirect_page attribute in the shortcode or the parameter in the block.
- Added a reCAPTCHA option for the customer order form.
- Added an option to send status update notifications to sales reps as well.
- Added filtering options to the export.
- Switched notes fields on the order edit screens to text areas.
- Styling updates to the Orders, Sales Reps and Customers admin screens.
- Fixed issue in which checkbox type custom fields were not saving correctly on the sales rep and customer edit screens.

= 3.1.0 (2022-02-01) =
- Updated escaping and sanitizing.
- Updated nonces and capability checks.
- Changed how premium settings areas are previewed.
- Fixed compatibility issue when using block-based themes.
- Added a location attribute to the customer order shortcode to specify the default/starting location for a submitted order.
- Added a dropdown to the customer order form block to select the default/starting location for a submitted order.

= 3.0.17 (2022-01-06) =
- A few styling fixes in the walk-through and admin panel.
- Updated nonces in the admin.
- Added a notice pertaining to the requirement of the premium helper plugin to access premium settings and content.

= 3.0.16 (2021-11-26) =
- Added an option to use what you set as your timezone in WordPress for the displayed timestamp for status updates. (By default, it uses your server's time, which may not be the same.)
- Made the order numbers links in the dashboard order summary area, which open the order edit screen.

= 3.0.15 (2021-11-03) =
- Update to SAP library version 2.6.1
- Makes a number of setting's display conditional on another setting having a specific value
- Fix for statuses incorrectly being set to internal during front-end updating at times
- Fix for a number of notices

= 3.0.14 (2021-10-18) =
- Fixes an issue where some sales reps were unable to access their orders in the admin

= 3.0.13 (2021-10-08) =
- Fixes an issue where custom fields were not being added correctly when sending emails with UWPM
- Removes a number of notices when the sales rep or customer aren't set but are being displayed in the order tracking results.

= 3.0.12 (2021-09-30) =
- Corrected an issue in which, in certain circumstances, the customer form and sales rep form were returning results when an invalid number/ID was input.

= 3.0.11 (2021-09-09) =
- Fix for WooCommerce order statuses always being reverted on deactivation.

= 3.0.10 (2021-09-08) =
- Updated the settings page library.
- Added a link type custom field.
- Updated so status email notifications are triggered when bulk updating orders via spreadsheet.
- Added option to set number of orders per page in the admin ORDERS tab
- Fix for status not being set when order submitted via the customer order form.
- Fix for email not being sent to customer when order submitted via the customer order form.
- Fix for emails created in Ultimate WP Mail not being sent on status change.

= 3.0.9 (2021-08-12) =
- Fixed Gutenberg blocks
- Updated deprecated block_categories

= 3.0.8 (2021-07-14) =
- Corrects an issue in which, in a rare instance, the update status form was showing on the front-end tracking page for non-logged in users.

= 3.0.7 (2021-07-02) =
- Fixed an issue in which, in some rare instances, the update status form was still showing on the front-end tracking page for non-logged in users.
- Fixed an issue in which the order tracking tags in the Ultimate WP Mail plugin were showing under the wrong label.
- Fixed a typo in the walk-through.

= 3.0.6 (2021-06-18) =
- Fixed an integration issue with the Ultimate WP Mail plugin, in which emails created in that plugin were not selectable for a status.

= 3.0.5 (2021-06-14) =
- Re-introduces the ability to update orders via import, if an order number in the spreadsheet matches an existing one. 
- Adds Location, Sales Rep and Customer to the export spreadsheet.

= 3.0.4 (2021-06-10) =
- Fixed an issue where changes to custom field values for an order were not showing on the front-end tracking page (it was showing an older value). 
- Localizing the delete button for individual statuses on the order edit screen.
- Eliminating a PHP notice.

= 3.0.3 (2021-06-03) =
- Fixed an issue with imported orders not being correctly assigned the specified status.
- Fixed an issue in which the tracking page update status feature was not working correctly. 
- Fixed an issue where the update status feature was sometimes showing on the tracking page for non-logged-in customers when the order was imported from spreadsheet and not yet edited or saved.
- Fixed an issue in which, if you typed, on the tracking page, an order number that didn't exist, it would display an empty template instead of the "no orders found" message.

= 3.0.2 (2021-05-28) =
- Fixed an issue with pagination on the orders admin screen.
- Fixed an issue with (not) being able to delete past statuses from the order edit screen.

= 3.0.1 (2021-05-25) =
- Added in the ability to have the tracking number be a link (to the tracking page) in the customer and sales rep forms when AJAX reloading is disabled.
- Added styling to the row hover when viewing the customer or sales rep form with AJAX enabled (not disabled) to make it more obvious that it is clickable (brings you to the tracking page for that order).
- Added (back) in the ability to show hidden orders in the admin orders table.
- Fixed an issue where the date filtering on the orders admin screen was sometimes blocking the other filters from being clickable.
- Fixed an error with bulk setting orders to a specific status. 
- Fixed an issue with setting orders to payment received.
- Fixed an issue in which the order ID was being displayed, instead of the order number, as part of the default thank you message after submitting the customer order form.

= 3.0.0 (2021-05-20) =
- <strong>This update includes quite a big change to the construction of the plugin, so please take caution and test before updating on a live site (or wait a few days before updating in case some minor corrective updates need to be released).</strong>
- Rebuilt the plugin, from the ground up, to be object oriented.
- Updated the structure of the settings pages.
- CSS/styling updates.
- Updates to the walk-through that runs on plugin activation.
- Fixed a few small issues with the WooCommerce integration and sync.
- Update to the statistics, so you can now see the number of views as well as data for the link clicking directly on the order edit screen.
- Updates to custom fields and how they tie in with customers and sales reps.
- Updated the custom fields edit screen.
- Fixed a few small issues with certain custom field types and the customer order form.
- Updates to several styling and labelling options.
- Updates to the conditional enqueuing of assets.
- Cleaning up/removing unnecessary code and files.
- Updated .pot file. (If you have created a translation based on the old version, you might need to update your .po file for this new version.)
